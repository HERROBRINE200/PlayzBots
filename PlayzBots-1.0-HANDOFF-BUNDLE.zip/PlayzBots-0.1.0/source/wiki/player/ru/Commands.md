# Команды

Все команды используют`/playzbots`префикс.

## Управление ботами

| Команда | Описание |
|---------|-------------|
| `/playzbots spawn [name]`| Создать бота (случайное имя, если опущено) |
| `/playzbots remove <name>`| Удалить конкретного бота |
| `/playzbots removeall`| Удалить всех ботов |
| `/playzbots reload`| Перезагрузить все конфигурации (настройки, комплекты, пути, боты) |
| `/playzbots bot-management list`| Список всех активных ботов |
| `/playzbots bot-management inventory <botname>`| Просмотр инвентаря и статистики ботов |
| `/playzbots bot-management mass-spawn <1-50>`| Создать несколько ботов |

## Боевой контроль

| Команда | Описание |
|---------|-------------|
| `/playzbots bot-management attack <botname> <target>`| Заставить бота атаковать цель |
| `/playzbots bot-management stop-attack <botname>`| Хватит атаковать |

## Настройки

| Команда | Описание |
|---------|-------------|
| `/playzbots settings`| Список всех текущих настроек |
| `/playzbots settings <name>`| Просмотр конкретной настройки |
| `/playzbots settings <name> <value>`| Установите значение параметра |

См. [Настройки](Настройки) для просмотра всех доступных опций.

## Пути

| Команда | Описание |
|---------|-------------|
| `/playzbots bot-management path create <name>`| Создать новый путь |
| `/playzbots bot-management path delete <name>`| Удалить путь |
| `/playzbots bot-management path add-point <name>`| Добавить текущую позицию в качестве путевой точки |
| `/playzbots bot-management path remove-point <name> [index]`| Удалить точку (последнюю или по индексу) |
| `/playzbots bot-management path clear <name>`| Очистить все точки |
| `/playzbots bot-management path loop <name> <true/false>`| Переключить цикл |
| `/playzbots bot-management path start <bot> <path>`| Запустить бота по пути |
| `/playzbots bot-management path stop <bot>`| Остановить бота, следуя по пути |
| `/playzbots bot-management path list`| Список всех путей |
| `/playzbots bot-management path show <name> <true/false>`| Переключить визуализацию пути |
| `/playzbots bot-management path info <name>`| Посмотреть детали пути |
| `/playzbots bot-management path distribute <path>`| Распределите ботов равномерно по пути |
| `/playzbots bot-management path start-near <path> <radius>`| Начальный путь для ближайших ботов |
| `/playzbots bot-management path stop-all <path>`| Остановить всех ботов на пути |
| `/playzbots bot-management path walk-type <name> <type>`| Установить тип ходьбы (подпрыгивание/спринт/ходьба) |

Подробную информацию об использовании см. в разделе [Пути](Пути).

## Комплекты

| Команда | Описание |
|---------|-------------|
| `/playzbots kit create-kit <name>`| Сохраните свой инвентарь как комплект |
| `/playzbots kit delete-kit <name>`| Удалить комплект |
| `/playzbots kit give-kit <player> <kitname>`| Отдать комплект игроку/боту |
| `/playzbots kit kits`| Список всех комплектов |
| `/playzbots kit give-kit-near <kitname> [radius]`| Раздать комплект ботам в радиусе действия (по умолчанию: 10) |
| `/playzbots kit give-kit-near-random <radius> <kit1> <w1>% [<kit2> <w2>% ...]`| Выдать случайно взвешенный комплект ботам в радиусе |

Подробную информацию об использовании см. в разделе [Наборы](Наборы).

## Фракции

| Команда | Описание |
|---------|-------------|
| `/playzbots faction list`| Список всех фракций |
| `/playzbots faction create <name>`| Создать фракцию |
| `/playzbots faction delete <name>`| Удалить фракцию |
| `/playzbots faction add <faction> <player>`| Добавить игрока/бота во фракцию |
| `/playzbots faction remove <faction> <player>`| Удалить игрока/бота из фракции |
| `/playzbots faction hostile <f1> <f2> [true/false]`| Установить враждебные отношения |
| `/playzbots faction info <name>`| Посмотреть информацию о фракции |
| `/playzbots faction add-near <faction> <radius>`| Добавить ближайших ботов во фракцию |
| `/playzbots faction add-all <faction>`| Добавить всех ботов во фракцию |
| `/playzbots faction give <faction> <item>`| Раздайте предметы всем участникам |
| `/playzbots faction attack <faction> <target>`| Все участники атакуют цель |
| `/playzbots faction path start <faction> <path>`| Все участники следуют по пути |
| `/playzbots faction path stop <faction>`| Остановить всех участников на пути |
| `/playzbots faction tp <faction> <x y z\|player>`| Постепенно телепортируйте всю фракцию |

### Команды набора фракций

| Команда | Описание |
|---------|-------------|
| `/playzbots faction kit give-kit <faction> <kitname>`| Раздайте комплект всем участникам |
| `/playzbots faction kit give-kit-random <faction> <kit1> <w1>% [<kit2> <w2>% ...]`| Раздайте членам фракции случайно взвешенный комплект |

Подробное описание см. в разделе [Фракции](Фракции).
