# Система путей

Создавайте пути к точкам, по которым будут следовать боты. Пути сохраняются для каждого мира в`config/playzbots/worlds/<worldname>/paths.json`.

## Команды

### Создание путей
```
/playzbots bot-management path create MyPath
```

### Добавление путевых точек
Встаньте в нужное место и бегите:
```
/playzbots bot-management path add-point MyPath
```
Визуализация пути (частиц) включается автоматически.

### Управление путевыми точками
```
/playzbots bot-management path remove-point MyPath      # Remove last
/playzbots bot-management path remove-point MyPath 0    # Remove by index
/playzbots bot-management path clear MyPath             # Clear all points
/playzbots bot-management path info MyPath              # List all points
/playzbots bot-management path list                     # List all paths
```

### Следование по путям
```
/playzbots bot-management path start Bot1 MyPath
/playzbots bot-management path stop Bot1
/playzbots bot-management path start-near MyPath 20     # Start for bots within 20 blocks
/playzbots bot-management path stop-all MyPath          # Stop all bots on path
```

### Распределение
Равномерно расположите ботов вдоль точек пути:
```
/playzbots bot-management path distribute MyPath
```

### Типы прогулок
```
/playzbots bot-management path walk-type MyPath bhop    # Bunny hop (default)
/playzbots bot-management path walk-type MyPath sprint  # Sprint
/playzbots bot-management path walk-type MyPath walk    # Walk
```

### Режим цикла
```
/playzbots bot-management path loop MyPath true
/playzbots bot-management path loop MyPath false
```

В циклическом режиме боты в конце меняют направление (пинг-понг). В режиме без цикла боты перезапускаются с самого начала.

### Визуализация
```
/playzbots bot-management path show MyPath true
/playzbots bot-management path show MyPath false
```

Показывает путевые точки пути в виде частиц (WAX_ON + линии зеленой пыли).

## Пути фракций

Управляйте всеми ботами во фракции одновременно:
```
/playzbots faction path start RedFaction MyPath
/playzbots faction path stop RedFaction
```

## Характеристики

| Недвижимость | Опции | По умолчанию |
|----------|---------|---------|
| Тип прогулки | хоп/спринт/ходьба | бхоп |
| Петля | правда/ложь | ложный |
| Атака | правда/ложь | правда |
| Очки | переменная (Vec3d) | - |
