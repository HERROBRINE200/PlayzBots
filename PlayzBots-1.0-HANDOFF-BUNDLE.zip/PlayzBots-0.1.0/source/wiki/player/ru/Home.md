# 🤖 ПВП-бот — Wiki

Добро пожаловать в официальную документацию PVP-бота!

---

## 📖 О нас

PlayzBots — это мод Minecraft Fabric, который добавляет интеллектуальных боевых ботов на базе мода HeroBot. Создавайте армии ботов, объединяйте их во фракции и наблюдайте, как разворачиваются эпические сражения!

---

## 🚀 Быстрый старт

1. Установите [Fabric Loader](https://fabricmc.net/) и [HeroBot Mod](https://modrinth.com/mod/herobot).
2. Загрузите PlayzBots и поместите его в свой`mods`папка
3. Запустите игру и используйте`/playzbots spawn BotName`чтобы создать своего первого бота!

---

## 📚 Документация

| Страница | Описание |
|------|-------------|
| [🎮 Команды](https://github.com/SatyamPlayz/PlayzBots/wiki/Commands) | Все доступные команды |
| [⚔️ Боевая система](https://github.com/SatyamPlayz/PlayzBots/wiki/Combat) | Как боты дерутся |
| [🚶 Навигация](https://github.com/SatyamPlayz/PlayzBots/wiki/Navigation) | Базовый поиск пути |
| [🛤️ Пути](https://github.com/SatyamPlayz/PlayzBots/wiki/Paths) | Система путей и путевые точки |
| [👥 Фракции](https://github.com/SatyamPlayz/PlayzBots/wiki/Factions) | Командная система |
| [🎒 Комплекты](https://github.com/SatyamPlayz/PlayzBots/wiki/Kits) | Пресеты оборудования |
| [⚙️ Настройки](https://github.com/SatyamPlayz/PlayzBots/wiki/Settings) | Все варианты конфигурации |

---

## 💡 Быстрые примеры

### Создайте простого бота
```
/playzbots spawn MyBot
```

### Заставьте две команды сражаться
```
/playzbots spawn Red1
/playzbots spawn Blue1
/playzbots faction create Red
/playzbots faction create Blue
/playzbots faction add Red Red1
/playzbots faction add Blue Blue1
/playzbots faction hostile Red Blue
```

---

## 🔗 Ссылки

- [Репозиторий GitHub](https://github.com/SatyamPlayz/PlayzBots)
- [Страница Модринта](https://modrinth.com/mod/pvp-bot)
- [Отчеты об ошибках](https://github.com/SatyamPlayz/PlayzBots/issues)
