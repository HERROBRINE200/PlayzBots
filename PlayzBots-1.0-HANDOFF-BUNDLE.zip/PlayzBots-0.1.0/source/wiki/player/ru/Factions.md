# Фракции

Организуйте ботов в команды/фракции для скоординированных сражений. Фракции сохраняются для каждого мира в`config/playzbots/worlds/<worldname>/factions.json`.

## Основные команды

### Создание и удаление
```
/playzbots faction create Red
/playzbots faction delete Red
```

### Управление участниками
```
/playzbots faction add Red Bot1
/playzbots faction remove Red Bot1
/playzbots faction add-near Red 30          # Add all bots within 30 blocks
/playzbots faction add-all Red              # Add all existing bots
```

### Проверить информацию
```
/playzbots faction list              # List all factions
/playzbots faction info Red          # Show members and enemies
```

## Враждебные отношения

Назначьте фракции врагами. Боты будут автоматически атаковать членов вражеской фракции.

```
/playzbots faction hostile Red Blue
/playzbots faction hostile Red Neutral false
```

**Примечание.** Враги всегда взаимны: установка красного враждебного синему также делает синего враждебным красному.

## Скоординированные действия

### Атака
Все члены фракции атакуют цель:
```
/playzbots faction attack Red GreenPlayer
```

### Отдать предметы
Раздайте предметы всем членам фракции:
```
/playzbots faction give Red diamond_sword 1
```

### Отдать комплект
Обеспечьте всех участников комплектом:
```
/playzbots faction kit give-kit Red MyKit
```

### Выдать случайный комплект
Снабдите членов фракции случайным взвешенным комплектом:
```
/playzbots faction kit give-kit-random Red warrior 60% archer 30% mage 10%
```

Каждый участник получает один комплект в зависимости от распределения веса.

### Телепорт
Телепортируйте всю фракцию постепенно (5 ботов за 100 мс):
```
/playzbots faction tp Red 100 64 -200
/playzbots faction tp Red ~ ~ ~
/playzbots faction tp Red PlayerName
```

Поддерживает абсолютные координаты, относительные`~`или нацеливаясь на игрока/бота по имени.

### Следование по пути
Все участники следуют по пути:
```
/playzbots faction path start Red MyPath
/playzbots faction path stop Red
```

## Настройки

| Настройка | По умолчанию | Описание |
|---------|---------|-------------|
| фракции | правда | Включить систему фракций |
| дружественный огонь | ложный | Разрешить атаковать членов собственной фракции |
