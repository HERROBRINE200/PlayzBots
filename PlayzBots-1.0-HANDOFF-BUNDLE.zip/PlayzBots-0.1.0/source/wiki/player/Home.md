# 🤖 PlayzBots - Wiki

Welcome to the official PlayzBots documentation!

---

## 📖 About

PlayzBots is a Minecraft Fabric mod that adds intelligent combat bots powered by HeroBot mod. Create armies of bots, organize them into factions, and watch epic battles unfold!

---

## 🚀 Quick Start

1. Install [Fabric Loader](https://fabricmc.net/) and [HeroBot Mod](https://modrinth.com/mod/herobot)
2. Download PlayzBots and put it in your `mods` folder
3. Start the game and use `/playzbots spawn BotName` to create your first bot!

---

## 📚 Documentation

| Page | Description |
|------|-------------|
| [🎮 Commands](https://github.com/SatyamPlayz/PlayzBots/wiki/Commands) | All available commands |
| [⚔️ Combat System](https://github.com/SatyamPlayz/PlayzBots/wiki/Combat) | How bots fight |
| [🚶 Navigation](https://github.com/SatyamPlayz/PlayzBots/wiki/Navigation) | Basic pathfinding |
| [🛤️ Paths](https://github.com/SatyamPlayz/PlayzBots/wiki/Paths) | Path system and waypoints |
| [👥 Factions](https://github.com/SatyamPlayz/PlayzBots/wiki/Factions) | Team system |
| [🎒 Kits](https://github.com/SatyamPlayz/PlayzBots/wiki/Kits) | Equipment presets |
| [⚙️ Settings](https://github.com/SatyamPlayz/PlayzBots/wiki/Settings) | All configuration options |

---

## 💡 Quick Examples

### Create a simple bot
```
/playzbots spawn MyBot
```

### Make two teams fight
```
/playzbots spawn Red1
/playzbots spawn Blue1
/playzbots faction create Red
/playzbots faction create Blue
/playzbots faction add Red Red1
/playzbots faction add Blue Blue1
/playzbots faction hostile Red Blue
```

---

## 🔗 Links

- [GitHub Repository](https://github.com/SatyamPlayz/PlayzBots)
- [Modrinth Page](https://modrinth.com/mod/pvp-bot)
- [Bug Reports](https://github.com/SatyamPlayz/PlayzBots/issues)
