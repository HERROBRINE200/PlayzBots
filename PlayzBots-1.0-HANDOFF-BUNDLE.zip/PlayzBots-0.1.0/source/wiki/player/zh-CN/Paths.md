# 路径系统

创建供机器人遵循的路径点路径。每个世界的路径保存在`config/playzbots/worlds/<worldname>/paths.json`。

## 命令

### 创建路径
```
/playzbots bot-management path create MyPath
```

### 添加航点
站在所需位置并运行：
```
/playzbots bot-management path add-point MyPath
```
路径可视化（粒子）自动启用。

### 管理航点
```
/playzbots bot-management path remove-point MyPath      # Remove last
/playzbots bot-management path remove-point MyPath 0    # Remove by index
/playzbots bot-management path clear MyPath             # Clear all points
/playzbots bot-management path info MyPath              # List all points
/playzbots bot-management path list                     # List all paths
```

### 遵循路径
```
/playzbots bot-management path start Bot1 MyPath
/playzbots bot-management path stop Bot1
/playzbots bot-management path start-near MyPath 20     # Start for bots within 20 blocks
/playzbots bot-management path stop-all MyPath          # Stop all bots on path
```

＃＃＃ 分配
沿路径点均匀分布机器人：
```
/playzbots bot-management path distribute MyPath
```

### 步行类型
```
/playzbots bot-management path walk-type MyPath bhop    # Bunny hop (default)
/playzbots bot-management path walk-type MyPath sprint  # Sprint
/playzbots bot-management path walk-type MyPath walk    # Walk
```

### 循环模式
```
/playzbots bot-management path loop MyPath true
/playzbots bot-management path loop MyPath false
```

在循环模式下，机器人在最后反转方向（乒乓球）。在非循环模式下，机器人从头开始。

### 可视化
```
/playzbots bot-management path show MyPath true
/playzbots bot-management path show MyPath false
```

将路径点显示为粒子（WAX_ON + 绿色灰尘线）。

## 派系路径

一次控制一个派系中的所有机器人：
```
/playzbots faction path start RedFaction MyPath
/playzbots faction path stop RedFaction
```

＃＃ 特性

|物业 |选项|默认|
|----------|---------|---------|
|步行类型| bhop / 冲刺 / 步行 |博普|
|循环|真/假|假 |
|攻击|真/假|真实 |
|积分 |变量 (Vec3d) | - |
