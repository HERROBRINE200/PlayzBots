# 🤖 PVP 机器人 - 维基

欢迎来到官方 PVP 机器人文档！

---

## 📖 关于

PlayzBots 是一个 Minecraft Fabric 模组，添加了由 HeroBot 模组提供支持的智能战斗机器人。创建机器人大军，将他们组织成派系，观看史诗般的战斗展开！

---

## 🚀 快速入门

1.安装[Fabric Loader](https://fabricmc.net/)和[HeroBot Mod](https://modrinth.com/mod/herobot)
2.下载PlayzBots并将其放入您的`mods`文件夹
3.启动游戏并使用`/playzbots spawn BotName`创建您的第一个机器人！

---

## 📚 文档

|页 |描述 |
|------|-------------|
| [🎮 命令](https://github.com/SatyamPlayz/PlayzBots/wiki/Commands) |所有可用命令 |
| [⚔️战斗系统](https://github.com/SatyamPlayz/PlayzBots/wiki/Combat) |机器人如何战斗 |
| [🚶 导航](https://github.com/SatyamPlayz/PlayzBots/wiki/Navigation) |基本寻路|
| [🛤️ 路径](https://github.com/SatyamPlayz/PlayzBots/wiki/Paths) |路径系统和航路点|
| [👥 派系](https://github.com/SatyamPlayz/PlayzBots/wiki/Factions) |团队体系|
| [🎒 套件](https://github.com/SatyamPlayz/PlayzBots/wiki/Kits) |设备预设|
| [⚙️ 设置](https://github.com/SatyamPlayz/PlayzBots/wiki/Settings) |所有配置选项|

---

## 💡 简单示例

### 创建一个简单的机器人
```
/playzbots spawn MyBot
```

### 让两队战斗
```
/playzbots spawn Red1
/playzbots spawn Blue1
/playzbots faction create Red
/playzbots faction create Blue
/playzbots faction add Red Red1
/playzbots faction add Blue Blue1
/playzbots faction hostile Red Blue
```

---

## 🔗 链接

- [GitHub 存储库](https://github.com/SatyamPlayz/PlayzBots)
- [莫德林斯页面](https://modrinth.com/mod/pvp-bot)
- [错误报告](https://github.com/SatyamPlayz/PlayzBots/issues)
