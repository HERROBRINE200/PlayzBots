# Path System

Create waypoint paths for bots to follow. Paths are saved per-world in `config/playzbots/worlds/<worldname>/paths.json`.

## Commands

### Creating Paths
```
/playzbots bot-management path create MyPath
```

### Adding Waypoints
Stand at the desired location and run:
```
/playzbots bot-management path add-point MyPath
```
Path visualization (particles) is automatically enabled.

### Managing Waypoints
```
/playzbots bot-management path remove-point MyPath      # Remove last
/playzbots bot-management path remove-point MyPath 0    # Remove by index
/playzbots bot-management path clear MyPath             # Clear all points
/playzbots bot-management path info MyPath              # List all points
/playzbots bot-management path list                     # List all paths
```

### Following Paths
```
/playzbots bot-management path start Bot1 MyPath
/playzbots bot-management path stop Bot1
/playzbots bot-management path start-near MyPath 20     # Start for bots within 20 blocks
/playzbots bot-management path stop-all MyPath          # Stop all bots on path
```

### Distribution
Evenly space bots along path points:
```
/playzbots bot-management path distribute MyPath
```

### Walk Types
```
/playzbots bot-management path walk-type MyPath bhop    # Bunny hop (default)
/playzbots bot-management path walk-type MyPath sprint  # Sprint
/playzbots bot-management path walk-type MyPath walk    # Walk
```

### Loop Mode
```
/playzbots bot-management path loop MyPath true
/playzbots bot-management path loop MyPath false
```

In loop mode, bots reverse direction at the end (ping-pong). In non-loop mode, bots restart from the beginning.

### Visualization
```
/playzbots bot-management path show MyPath true
/playzbots bot-management path show MyPath false
```

Shows path waypoints as particles (WAX_ON + green dust lines).

## Faction Paths

Control all bots in a faction at once:
```
/playzbots faction path start RedFaction MyPath
/playzbots faction path stop RedFaction
```

## Properties

| Property | Options | Default |
|----------|---------|---------|
| Walk Type | bhop / sprint / walk | bhop |
| Loop | true / false | false |
| Attack | true / false | true |
| Points | variable (Vec3d) | - |
