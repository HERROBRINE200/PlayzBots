# Commands

All commands use the `/playzbots` prefix.

## Bot Management

| Command | Description |
|---------|-------------|
| `/playzbots spawn [name]` | Spawn a bot (random name if omitted) |
| `/playzbots remove <name>` | Remove a specific bot |
| `/playzbots removeall` | Remove all bots |
| `/playzbots reload` | Reload all configurations (settings, kits, paths, bots) |
| `/playzbots bot-management list` | List all active bots |
| `/playzbots bot-management inventory <botname>` | View bot inventory and stats |
| `/playzbots bot-management mass-spawn <1-50>` | Spawn multiple bots |

## Combat Control

| Command | Description |
|---------|-------------|
| `/playzbots bot-management attack <botname> <target>` | Force bot to attack a target |
| `/playzbots bot-management stop-attack <botname>` | Stop attacking |

## Settings

| Command | Description |
|---------|-------------|
| `/playzbots settings` | List all current settings |
| `/playzbots settings <name>` | View a specific setting |
| `/playzbots settings <name> <value>` | Set a setting value |

See [Settings](Settings) for all available options.

## Paths

| Command | Description |
|---------|-------------|
| `/playzbots bot-management path create <name>` | Create a new path |
| `/playzbots bot-management path delete <name>` | Delete a path |
| `/playzbots bot-management path add-point <name>` | Add current position as waypoint |
| `/playzbots bot-management path remove-point <name> [index]` | Remove point (last or by index) |
| `/playzbots bot-management path clear <name>` | Clear all points |
| `/playzbots bot-management path loop <name> <true/false>` | Toggle looping |
| `/playzbots bot-management path start <bot> <path>` | Start bot following path |
| `/playzbots bot-management path stop <bot>` | Stop bot following path |
| `/playzbots bot-management path list` | List all paths |
| `/playzbots bot-management path show <name> <true/false>` | Toggle path visualization |
| `/playzbots bot-management path info <name>` | View path details |
| `/playzbots bot-management path distribute <path>` | Spread bots evenly along path |
| `/playzbots bot-management path start-near <path> <radius>` | Start path for nearby bots |
| `/playzbots bot-management path stop-all <path>` | Stop all bots on path |
| `/playzbots bot-management path walk-type <name> <type>` | Set walk type (bhop/sprint/walk) |

See [Paths](Paths) for detailed usage.

## Kits

| Command | Description |
|---------|-------------|
| `/playzbots kit create-kit <name>` | Save your inventory as a kit |
| `/playzbots kit delete-kit <name>` | Delete a kit |
| `/playzbots kit give-kit <player> <kitname>` | Give kit to player/bot |
| `/playzbots kit kits` | List all kits |
| `/playzbots kit give-kit-near <kitname> [radius]` | Give kit to bots within radius (default: 10) |
| `/playzbots kit give-kit-near-random <radius> <kit1> <w1>% [<kit2> <w2>% ...]` | Give random weighted kit to bots within radius |

See [Kits](Kits) for detailed usage.

## Factions

| Command | Description |
|---------|-------------|
| `/playzbots faction list` | List all factions |
| `/playzbots faction create <name>` | Create a faction |
| `/playzbots faction delete <name>` | Delete a faction |
| `/playzbots faction add <faction> <player>` | Add player/bot to faction |
| `/playzbots faction remove <faction> <player>` | Remove player/bot from faction |
| `/playzbots faction hostile <f1> <f2> [true/false]` | Set hostile relations |
| `/playzbots faction info <name>` | View faction info |
| `/playzbots faction add-near <faction> <radius>` | Add nearby bots to faction |
| `/playzbots faction add-all <faction>` | Add all bots to faction |
| `/playzbots faction give <faction> <item>` | Give items to all members |
| `/playzbots faction attack <faction> <target>` | All members attack target |
| `/playzbots faction path start <faction> <path>` | All members follow path |
| `/playzbots faction path stop <faction>` | Stop all members on path |
| `/playzbots faction tp <faction> <x y z\|player>` | Teleport entire faction gradually |

### Faction Kit Commands

| Command | Description |
|---------|-------------|
| `/playzbots faction kit give-kit <faction> <kitname>` | Give kit to all members |
| `/playzbots faction kit give-kit-random <faction> <kit1> <w1>% [<kit2> <w2>% ...]` | Give random weighted kit to faction members |

See [Factions](Factions) for detailed usage.
