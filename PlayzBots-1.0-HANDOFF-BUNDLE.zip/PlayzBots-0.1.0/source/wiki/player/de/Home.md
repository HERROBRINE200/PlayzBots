# 🤖 PVP-Bot – Wiki

Willkommen zur offiziellen PVP-Bot-Dokumentation!

---

## 📖 Ungefähr

PlayzBots ist ein Minecraft Fabric-Mod, der intelligente Kampfbots hinzufügt, die vom HeroBot-Mod unterstützt werden. Erstelle Armeen aus Bots, organisiere sie in Fraktionen und sieh zu, wie sich epische Schlachten entfalten!

---

## 🚀 Schnellstart

1. Installieren Sie [Fabric Loader](https://fabricmc.net/) und [HeroBot Mod](https://modrinth.com/mod/herobot)
2. Laden Sie den PlayzBots herunter und installieren Sie ihn in Ihrem`mods`Ordner
3. Starten Sie das Spiel und verwenden Sie es`/playzbots spawn BotName`um deinen ersten Bot zu erstellen!

---

## 📚 Dokumentation

| Seite | Beschreibung |
|------|-------------|
| [🎮 Befehle](https://github.com/SatyamPlayz/PlayzBots/wiki/Commands) | Alle verfügbaren Befehle |
| [⚔️ Kampfsystem](https://github.com/SatyamPlayz/PlayzBots/wiki/Combat) | Wie Bots kämpfen |
| [🚶 Navigation](https://github.com/SatyamPlayz/PlayzBots/wiki/Navigation) | Grundlegende Wegfindung |
| [🛤️ Pfade](https://github.com/SatyamPlayz/PlayzBots/wiki/Paths) | Pfadsystem und Wegpunkte |
| [👥 Fraktionen](https://github.com/SatyamPlayz/PlayzBots/wiki/Factions) | Teamsystem |
| [🎒 Kits](https://github.com/SatyamPlayz/PlayzBots/wiki/Kits) | Gerätevoreinstellungen |
| [⚙️ Einstellungen](https://github.com/SatyamPlayz/PlayzBots/wiki/Settings) | Alle Konfigurationsoptionen |

---

## 💡 Schnelle Beispiele

### Erstellen Sie einen einfachen Bot
```
/playzbots spawn MyBot
```

### Lass zwei Teams kämpfen
```
/playzbots spawn Red1
/playzbots spawn Blue1
/playzbots faction create Red
/playzbots faction create Blue
/playzbots faction add Red Red1
/playzbots faction add Blue Blue1
/playzbots faction hostile Red Blue
```

---

## 🔗 Links

- [GitHub-Repository](https://github.com/SatyamPlayz/PlayzBots)
- [Modrinth-Seite](https://modrinth.com/mod/pvp-bot)
- [Fehlerberichte](https://github.com/SatyamPlayz/PlayzBots/issues)
