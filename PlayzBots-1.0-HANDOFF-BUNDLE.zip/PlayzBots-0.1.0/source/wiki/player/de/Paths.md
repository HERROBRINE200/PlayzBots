# Pfadsystem

Erstellen Sie Wegpunktpfade, denen Bots folgen können. Pfade werden pro Welt gespeichert`config/playzbots/worlds/<worldname>/paths.json`.

## Befehle

### Pfade erstellen
```
/playzbots bot-management path create MyPath
```

### Wegpunkte hinzufügen
Stellen Sie sich an die gewünschte Stelle und führen Sie Folgendes aus:
```
/playzbots bot-management path add-point MyPath
```
Die Pfadvisualisierung (Partikel) ist automatisch aktiviert.

### Wegpunkte verwalten
```
/playzbots bot-management path remove-point MyPath      # Remove last
/playzbots bot-management path remove-point MyPath 0    # Remove by index
/playzbots bot-management path clear MyPath             # Clear all points
/playzbots bot-management path info MyPath              # List all points
/playzbots bot-management path list                     # List all paths
```

### Den Pfaden folgen
```
/playzbots bot-management path start Bot1 MyPath
/playzbots bot-management path stop Bot1
/playzbots bot-management path start-near MyPath 20     # Start for bots within 20 blocks
/playzbots bot-management path stop-all MyPath          # Stop all bots on path
```

### Verteilung
Verteilen Sie Bots gleichmäßig entlang der Pfadpunkte:
```
/playzbots bot-management path distribute MyPath
```

### Geharten
```
/playzbots bot-management path walk-type MyPath bhop    # Bunny hop (default)
/playzbots bot-management path walk-type MyPath sprint  # Sprint
/playzbots bot-management path walk-type MyPath walk    # Walk
```

### Loop-Modus
```
/playzbots bot-management path loop MyPath true
/playzbots bot-management path loop MyPath false
```

Im Loop-Modus kehren die Bots am Ende die Richtung um (Ping-Pong). Im Nicht-Loop-Modus starten Bots von vorne.

### Visualisierung
```
/playzbots bot-management path show MyPath true
/playzbots bot-management path show MyPath false
```

Zeigt Pfadwegpunkte als Partikel an (WAX_ON + grüne Staublinien).

## Fraktionspfade

Kontrolliere alle Bots einer Fraktion gleichzeitig:
```
/playzbots faction path start RedFaction MyPath
/playzbots faction path stop RedFaction
```

## Eigenschaften

| Eigentum | Optionen | Standard |
|----------|---------|---------|
| Gehtyp | bhop / sprint / gehen | bhop |
| Schleife | wahr / falsch | falsch |
| Angriff | wahr / falsch | wahr |
| Punkte | Variable (Vec3d) | - |
