# Befehle

Alle Befehle verwenden die`/playzbots`Präfix.

## Bot-Management

| Befehl | Beschreibung |
|---------|-------------|
| `/playzbots spawn [name]`| Einen Bot erzeugen (zufälliger Name, falls weggelassen) |
| `/playzbots remove <name>`| Einen bestimmten Bot entfernen |
| `/playzbots removeall`| Alle Bots entfernen |
| `/playzbots reload`| Alle Konfigurationen (Einstellungen, Kits, Pfade, Bots) neu laden |
| `/playzbots bot-management list`| Alle aktiven Bots auflisten |
| `/playzbots bot-management inventory <botname>`| Bot-Inventar und Statistiken anzeigen |
| `/playzbots bot-management mass-spawn <1-50>`| Mehrere Bots erzeugen |

## Kampfkontrolle

| Befehl | Beschreibung |
|---------|-------------|
| `/playzbots bot-management attack <botname> <target>`| Bot zwingen, ein Ziel anzugreifen |
| `/playzbots bot-management stop-attack <botname>`| Hör auf anzugreifen |

## Einstellungen

| Befehl | Beschreibung |
|---------|-------------|
| `/playzbots settings`| Alle aktuellen Einstellungen auflisten |
| `/playzbots settings <name>`| Eine bestimmte Einstellung anzeigen |
| `/playzbots settings <name> <value>`| Legen Sie einen Einstellwert fest |

Alle verfügbaren Optionen finden Sie unter [Einstellungen](Einstellungen).

## Pfade

| Befehl | Beschreibung |
|---------|-------------|
| `/playzbots bot-management path create <name>`| Erstellen Sie einen neuen Pfad |
| `/playzbots bot-management path delete <name>`| Einen Pfad löschen |
| `/playzbots bot-management path add-point <name>`| Aktuelle Position als Wegpunkt hinzufügen |
| `/playzbots bot-management path remove-point <name> [index]`| Punkt entfernen (letzter oder nach Index) |
| `/playzbots bot-management path clear <name>`| Alle Punkte löschen |
| `/playzbots bot-management path loop <name> <true/false>`| Schleife umschalten |
| `/playzbots bot-management path start <bot> <path>`| Starten Sie den Bot und folgen Sie dem Pfad |
| `/playzbots bot-management path stop <bot>`| Bot stoppen, dem Pfad zu folgen |
| `/playzbots bot-management path list`| Alle Pfade auflisten |
| `/playzbots bot-management path show <name> <true/false>`| Pfadvisualisierung umschalten |
| `/playzbots bot-management path info <name>`| Pfaddetails anzeigen |
| `/playzbots bot-management path distribute <path>`| Bots gleichmäßig entlang des Pfades verteilen |
| `/playzbots bot-management path start-near <path> <radius>`| Startpfad für Bots in der Nähe |
| `/playzbots bot-management path stop-all <path>`| Stoppen Sie alle Bots auf Pfad |
| `/playzbots bot-management path walk-type <name> <type>`| Lauftyp einstellen (Bhop/Sprint/Walk) |

Ausführliche Informationen zur Verwendung finden Sie unter [Pfade](Pfade).

## Bausätze

| Befehl | Beschreibung |
|---------|-------------|
| `/playzbots kit create-kit <name>`| Speichern Sie Ihr Inventar als Bausatz |
| `/playzbots kit delete-kit <name>`| Ein Kit löschen |
| `/playzbots kit give-kit <player> <kitname>`| Gib dem Spieler/Bot das Kit |
| `/playzbots kit kits`| Alle Kits auflisten |
| `/playzbots kit give-kit-near <kitname> [radius]`| Kit an Bots im Umkreis weitergeben (Standard: 10) |
| `/playzbots kit give-kit-near-random <radius> <kit1> <w1>% [<kit2> <w2>% ...]`| Geben Sie Bots im Umkreis ein zufällig gewichtetes Kit |

Detaillierte Informationen zur Verwendung finden Sie unter [Kits](Kits).

## Fraktionen

| Befehl | Beschreibung |
|---------|-------------|
| `/playzbots faction list`| Alle Fraktionen auflisten |
| `/playzbots faction create <name>`| Erstelle eine Fraktion |
| `/playzbots faction delete <name>`| Eine Fraktion löschen |
| `/playzbots faction add <faction> <player>`| Spieler/Bot zur Fraktion hinzufügen |
| `/playzbots faction remove <faction> <player>`| Spieler/Bot aus Fraktion entfernen |
| `/playzbots faction hostile <f1> <f2> [true/false]`| Feindliche Beziehungen einstellen |
| `/playzbots faction info <name>`| Fraktionsinfo anzeigen |
| `/playzbots faction add-near <faction> <radius>`| Bots in der Nähe zur Fraktion hinzufügen |
| `/playzbots faction add-all <faction>`| Alle Bots zur Fraktion hinzufügen |
| `/playzbots faction give <faction> <item>`| Gegenstände an alle Mitglieder verschenken |
| `/playzbots faction attack <faction> <target>`| Alle Mitglieder greifen Ziel an |
| `/playzbots faction path start <faction> <path>`| Alle Mitglieder folgen dem Pfad |
| `/playzbots faction path stop <faction>`| Stoppen Sie alle Mitglieder auf Pfad |
| `/playzbots faction tp <faction> <x y z\|player>`| Ganze Fraktion nach und nach teleportieren |

### Fraktionskit-Befehle

| Befehl | Beschreibung |
|---------|-------------|
| `/playzbots faction kit give-kit <faction> <kitname>`| Kit an alle Mitglieder weitergeben |
| `/playzbots faction kit give-kit-random <faction> <kit1> <w1>% [<kit2> <w2>% ...]`| Geben Sie den Fraktionsmitgliedern ein zufällig gewichtetes Kit |

Weitere Informationen zur Verwendung finden Sie unter [Fraktionen](Fraktionen).
