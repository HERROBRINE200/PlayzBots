# facciones

Organiza bots en equipos/facciones para batallas coordinadas. Las facciones se guardan por mundo en`config/playzbots/worlds/<worldname>/factions.json`.

## Comandos básicos

### Crear y eliminar
```
/playzbots faction create Red
/playzbots faction delete Red
```

### Administrar miembros
```
/playzbots faction add Red Bot1
/playzbots faction remove Red Bot1
/playzbots faction add-near Red 30          # Add all bots within 30 blocks
/playzbots faction add-all Red              # Add all existing bots
```

### Verificar información
```
/playzbots faction list              # List all factions
/playzbots faction info Red          # Show members and enemies
```

## Relaciones hostiles

Establece facciones como enemigas. Los bots atacarán automáticamente a los miembros de la facción enemiga.

```
/playzbots faction hostile Red Blue
/playzbots faction hostile Red Neutral false
```

**Nota:** Los enemigos siempre son mutuos: establecer que Rojo sea hostil hacia Azul también hace que Azul sea hostil hacia Rojo.

## Acciones Coordinadas

### Ataque
Todos los miembros de la facción atacan a un objetivo:
```
/playzbots faction attack Red GreenPlayer
```

### Dar artículos
Entrega artículos a todos los miembros de la facción:
```
/playzbots faction give Red diamond_sword 1
```

### Dar kit
Equipa a todos los miembros con un kit:
```
/playzbots faction kit give-kit Red MyKit
```

### Dar kit aleatorio
Equipa a los miembros de la facción con un kit ponderado aleatorio:
```
/playzbots faction kit give-kit-random Red warrior 60% archer 30% mage 10%
```

Cada miembro recibe un kit según la distribución del peso.

### Teletransportarse
Teletransporta a toda la facción gradualmente (5 bots cada 100 ms):
```
/playzbots faction tp Red 100 64 -200
/playzbots faction tp Red ~ ~ ~
/playzbots faction tp Red PlayerName
```

Soporta coordenadas absolutas, relativas`~`, o apuntar a un jugador/bot por su nombre.

### Seguimiento de ruta
Todos los miembros siguen un camino:
```
/playzbots faction path start Red MyPath
/playzbots faction path stop Red
```

## Ajustes

| Configuración | Predeterminado | Descripción |
|---------|---------|-------------|
| facciones | verdadero | Habilitar sistema de facciones |
| fuego amigo | falso | Permitir atacar a miembros de la propia facción |
