# 🤖 Bot PvP - Wiki

¡Bienvenido a la documentación oficial de PlayzBots!

---

## 📖 Acerca de

PlayzBots es un mod de Minecraft Fabric que agrega robots de combate inteligentes impulsados ​​por el mod HeroBot. ¡Crea ejércitos de robots, organízalos en facciones y observa cómo se desarrollan batallas épicas!

---

## 🚀 Inicio rápido

1. Instale [Fabric Loader](https://fabricmc.net/) y [HeroBot Mod](https://modrinth.com/mod/herobot)
2. Descarga PlayzBots y colócalo en tu`mods`carpeta
3. Inicie el juego y use`/playzbots spawn BotName`para crear tu primer bot!

---

## 📚 Documentación

| Página | Descripción |
|------|-------------|
| [🎮 Comandos](https://github.com/SatyamPlayz/PlayzBots/wiki/Commands) | Todos los comandos disponibles |
| [⚔️ Sistema de combate](https://github.com/SatyamPlayz/PlayzBots/wiki/Combat) | Cómo luchan los robots |
| [🚶 Navegación](https://github.com/SatyamPlayz/PlayzBots/wiki/Navigation) | Búsqueda de caminos básicos |
| [🛤️ Rutas](https://github.com/SatyamPlayz/PlayzBots/wiki/Paths) | Sistema de rutas y puntos de referencia |
| [👥 Facciones](https://github.com/SatyamPlayz/PlayzBots/wiki/Factions) | Sistema de equipo |
| [🎒 Kits](https://github.com/SatyamPlayz/PlayzBots/wiki/Kits) | Preajustes de equipos |
| [⚙️ Configuración](https://github.com/SatyamPlayz/PlayzBots/wiki/Settings) | Todas las opciones de configuración |

---

## 💡 Ejemplos rápidos

### Crea un bot simple
```
/playzbots spawn MyBot
```

### Haz que dos equipos peleen
```
/playzbots spawn Red1
/playzbots spawn Blue1
/playzbots faction create Red
/playzbots faction create Blue
/playzbots faction add Red Red1
/playzbots faction add Blue Blue1
/playzbots faction hostile Red Blue
```

---

## 🔗 Enlaces

- [Repositorio de GitHub] (https://github.com/SatyamPlayz/PlayzBots)
- [Página de Modrinth](https://modrinth.com/mod/pvp-bot)
- [Informes de errores](https://github.com/SatyamPlayz/PlayzBots/issues)
