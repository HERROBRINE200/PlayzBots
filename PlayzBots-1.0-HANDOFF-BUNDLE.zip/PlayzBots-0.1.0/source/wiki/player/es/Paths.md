# Sistema de ruta

Cree rutas de puntos de referencia para que las sigan los robots. Los caminos se guardan por mundo en`config/playzbots/worlds/<worldname>/paths.json`.

## Comandos

### Creando caminos
```
/playzbots bot-management path create MyPath
```

### Agregar puntos de referencia
Párese en la ubicación deseada y ejecute:
```
/playzbots bot-management path add-point MyPath
```
La visualización de rutas (partículas) se habilita automáticamente.

### Gestión de puntos de referencia
```
/playzbots bot-management path remove-point MyPath      # Remove last
/playzbots bot-management path remove-point MyPath 0    # Remove by index
/playzbots bot-management path clear MyPath             # Clear all points
/playzbots bot-management path info MyPath              # List all points
/playzbots bot-management path list                     # List all paths
```

### Siguiendo caminos
```
/playzbots bot-management path start Bot1 MyPath
/playzbots bot-management path stop Bot1
/playzbots bot-management path start-near MyPath 20     # Start for bots within 20 blocks
/playzbots bot-management path stop-all MyPath          # Stop all bots on path
```

### Distribución
Distribuya uniformemente los robots a lo largo de los puntos del camino:
```
/playzbots bot-management path distribute MyPath
```

### Tipos de caminata
```
/playzbots bot-management path walk-type MyPath bhop    # Bunny hop (default)
/playzbots bot-management path walk-type MyPath sprint  # Sprint
/playzbots bot-management path walk-type MyPath walk    # Walk
```

### Modo bucle
```
/playzbots bot-management path loop MyPath true
/playzbots bot-management path loop MyPath false
```

In loop mode, bots reverse direction at the end (ping-pong). In non-loop mode, bots restart from the beginning.

### Visualización
```
/playzbots bot-management path show MyPath true
/playzbots bot-management path show MyPath false
```

Muestra los puntos de ruta como partículas (WAX_ON + líneas de polvo verdes).

## Caminos de facción

Controla todos los bots de una facción a la vez:
```
/playzbots faction path start RedFaction MyPath
/playzbots faction path stop RedFaction
```

## Propiedades

| Propiedad | Opciones | Predeterminado |
|----------|---------|---------|
| Tipo de caminata | bhop / sprint / caminata | bhop |
| Bucle | verdadero/falso | falso |
| Ataque | verdadero/falso | verdadero |
| Puntos | variables (Vec3d) | - |
