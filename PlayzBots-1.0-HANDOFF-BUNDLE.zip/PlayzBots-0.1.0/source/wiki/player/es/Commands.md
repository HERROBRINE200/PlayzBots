# Comandos

Todos los comandos utilizan el`/playzbots`prefijo.

## Gestión de robots

| Comando | Descripción |
|---------|-------------|
| `/playzbots spawn [name]`| Generar un bot (nombre aleatorio si se omite) |
| `/playzbots remove <name>`| Eliminar un bot específico |
| `/playzbots removeall`| Eliminar todos los robots |
| `/playzbots reload`| Recargar todas las configuraciones (configuraciones, kits, rutas, bots) |
| `/playzbots bot-management list`| Listar todos los bots activos |
| `/playzbots bot-management inventory <botname>`| Ver inventario y estadísticas de bots |
| `/playzbots bot-management mass-spawn <1-50>`| Generar múltiples bots |

## Control de combate

| Comando | Descripción |
|---------|-------------|
| `/playzbots bot-management attack <botname> <target>`| Forzar al robot a atacar a un objetivo |
| `/playzbots bot-management stop-attack <botname>`| Deja de atacar |

## Ajustes

| Comando | Descripción |
|---------|-------------|
| `/playzbots settings`| Listar todas las configuraciones actuales |
| `/playzbots settings <name>`| Ver una configuración específica |
| `/playzbots settings <name> <value>`| Establecer un valor de configuración |

Consulte [Configuración](Configuración) para conocer todas las opciones disponibles.

## Caminos

| Comando | Descripción |
|---------|-------------|
| `/playzbots bot-management path create <name>`| Crear una nueva ruta |
| `/playzbots bot-management path delete <name>`| Eliminar una ruta |
| `/playzbots bot-management path add-point <name>`| Agregar posición actual como waypoint |
| `/playzbots bot-management path remove-point <name> [index]`| Eliminar punto (último o por índice) |
| `/playzbots bot-management path clear <name>`| Borrar todos los puntos |
| `/playzbots bot-management path loop <name> <true/false>`| Alternar bucle |
| `/playzbots bot-management path start <bot> <path>`| Iniciar bot siguiendo la ruta |
| `/playzbots bot-management path stop <bot>`| Dejar que el bot siga la ruta |
| `/playzbots bot-management path list`| Listar todas las rutas |
| `/playzbots bot-management path show <name> <true/false>`| Alternar visualización de ruta |
| `/playzbots bot-management path info <name>`| Ver detalles de la ruta |
| `/playzbots bot-management path distribute <path>`| Distribuya los robots de manera uniforme a lo largo del camino |
| `/playzbots bot-management path start-near <path> <radius>`| Ruta de inicio para bots cercanos |
| `/playzbots bot-management path stop-all <path>`| Detener todos los robots en el camino |
| `/playzbots bot-management path walk-type <name> <type>`| Establecer tipo de caminata (bhop/sprint/walk) |

Consulte [Rutas](Rutas) para conocer el uso detallado.

## Equipos

| Comando | Descripción |
|---------|-------------|
| `/playzbots kit create-kit <name>`| Guarde su inventario como un kit |
| `/playzbots kit delete-kit <name>`| Eliminar un kit |
| `/playzbots kit give-kit <player> <kitname>`| Entregar el kit al jugador/bot |
| `/playzbots kit kits`| Listar todos los kits |
| `/playzbots kit give-kit-near <kitname> [radius]`| Dar kit a los bots dentro del radio (predeterminado: 10) |
| `/playzbots kit give-kit-near-random <radius> <kit1> <w1>% [<kit2> <w2>% ...]`| Dar un kit ponderado aleatorio a los bots dentro del radio |

Consulte [Kits](Kits) para conocer su uso detallado.

## facciones

| Comando | Descripción |
|---------|-------------|
| `/playzbots faction list`| Listar todas las facciones |
| `/playzbots faction create <name>`| Crear una facción |
| `/playzbots faction delete <name>`| Eliminar una facción |
| `/playzbots faction add <faction> <player>`| Agregar jugador/bot a la facción |
| `/playzbots faction remove <faction> <player>`| Eliminar jugador/bot de la facción |
| `/playzbots faction hostile <f1> <f2> [true/false]`| Establecer relaciones hostiles |
| `/playzbots faction info <name>`| Ver información de facción |
| `/playzbots faction add-near <faction> <radius>`| Agregar bots cercanos a la facción |
| `/playzbots faction add-all <faction>`| Agregar todos los bots a la facción |
| `/playzbots faction give <faction> <item>`| Dar artículos a todos los miembros |
| `/playzbots faction attack <faction> <target>`| Todos los miembros atacan al objetivo |
| `/playzbots faction path start <faction> <path>`| Todos los miembros siguen el camino |
| `/playzbots faction path stop <faction>`| Detener a todos los miembros en el camino |
| `/playzbots faction tp <faction> <x y z\|player>`| Teletransporta a toda la facción gradualmente |

### Comandos del kit de facción

| Comando | Descripción |
|---------|-------------|
| `/playzbots faction kit give-kit <faction> <kitname>`| Entregar kit a todos los miembros |
| `/playzbots faction kit give-kit-random <faction> <kit1> <w1>% [<kit2> <w2>% ...]`| Entregar un kit ponderado aleatorio a los miembros de la facción |

Consulta [Factions](Factions) para conocer su uso detallado.
