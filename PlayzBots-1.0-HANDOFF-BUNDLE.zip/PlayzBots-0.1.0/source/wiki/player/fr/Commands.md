# Commandes

Toutes les commandes utilisent le`/playzbots`préfixe.

## Gestion des robots

| Commande | Descriptif |
|---------|-------------|
| `/playzbots spawn [name]`| Générer un bot (nom aléatoire si omis) |
| `/playzbots remove <name>`| Supprimer un bot spécifique |
| `/playzbots removeall`| Supprimer tous les robots |
| `/playzbots reload`| Recharger toutes les configurations (paramètres, kits, chemins, bots) |
| `/playzbots bot-management list`| Lister tous les robots actifs |
| `/playzbots bot-management inventory <botname>`| Afficher l'inventaire et les statistiques des robots |
| `/playzbots bot-management mass-spawn <1-50>`| Générer plusieurs robots |

## Contrôle des combats

| Commande | Descriptif |
|---------|-------------|
| `/playzbots bot-management attack <botname> <target>`| Forcer le bot à attaquer une cible |
| `/playzbots bot-management stop-attack <botname>`| Arrêtez d'attaquer |

## Paramètres

| Commande | Descriptif |
|---------|-------------|
| `/playzbots settings`| Répertorier tous les paramètres actuels |
| `/playzbots settings <name>`| Afficher un paramètre spécifique |
| `/playzbots settings <name> <value>`| Définir une valeur de paramètre |

Voir [Paramètres](Paramètres) pour toutes les options disponibles.

## Chemins

| Commande | Descriptif |
|---------|-------------|
| `/playzbots bot-management path create <name>`| Créer un nouveau chemin |
| `/playzbots bot-management path delete <name>`| Supprimer un chemin |
| `/playzbots bot-management path add-point <name>`| Ajouter la position actuelle comme waypoint |
| `/playzbots bot-management path remove-point <name> [index]`| Supprimer le point (dernier ou par index) |
| `/playzbots bot-management path clear <name>`| Effacer tous les points |
| `/playzbots bot-management path loop <name> <true/false>`| Activer/désactiver la boucle |
| `/playzbots bot-management path start <bot> <path>`| Démarrer le bot en suivant le chemin |
| `/playzbots bot-management path stop <bot>`| Arrêter le robot de suivre le chemin |
| `/playzbots bot-management path list`| Liste tous les chemins |
| `/playzbots bot-management path show <name> <true/false>`| Basculer la visualisation du chemin |
| `/playzbots bot-management path info <name>`| Afficher les détails du chemin |
| `/playzbots bot-management path distribute <path>`| Répartissez les robots uniformément le long du chemin |
| `/playzbots bot-management path start-near <path> <radius>`| Chemin de départ pour les robots à proximité |
| `/playzbots bot-management path stop-all <path>`| Arrêtez tous les robots sur le chemin |
| `/playzbots bot-management path walk-type <name> <type>`| Définir le type de marche (bhop/sprint/walk) |

Voir [Chemins](Chemins) pour une utilisation détaillée.

## Trousses

| Commande | Descriptif |
|---------|-------------|
| `/playzbots kit create-kit <name>`| Enregistrez votre inventaire sous forme de kit |
| `/playzbots kit delete-kit <name>`| Supprimer un kit |
| `/playzbots kit give-kit <player> <kitname>`| Donner le kit au joueur/bot |
| `/playzbots kit kits`| Liste de tous les kits |
| `/playzbots kit give-kit-near <kitname> [radius]`| Donner un kit aux robots dans le rayon (par défaut : 10) |
| `/playzbots kit give-kit-near-random <radius> <kit1> <w1>% [<kit2> <w2>% ...]`| Donnez un kit pondéré aléatoirement aux robots dans un rayon |

Voir [Kits](Kits) pour une utilisation détaillée.

## Factions

| Commande | Descriptif |
|---------|-------------|
| `/playzbots faction list`| Liste toutes les factions |
| `/playzbots faction create <name>`| Créer une faction |
| `/playzbots faction delete <name>`| Supprimer une faction |
| `/playzbots faction add <faction> <player>`| Ajouter un joueur/bot à la faction |
| `/playzbots faction remove <faction> <player>`| Supprimer le joueur/bot de la faction |
| `/playzbots faction hostile <f1> <f2> [true/false]`| Définir des relations hostiles |
| `/playzbots faction info <name>`| Afficher les informations sur les factions |
| `/playzbots faction add-near <faction> <radius>`| Ajouter des robots à proximité à la faction |
| `/playzbots faction add-all <faction>`| Ajouter tous les robots à la faction |
| `/playzbots faction give <faction> <item>`| Offrez des objets à tous les membres |
| `/playzbots faction attack <faction> <target>`| Tous les membres attaquent la cible |
| `/playzbots faction path start <faction> <path>`| Tous les membres suivent le chemin |
| `/playzbots faction path stop <faction>`| Arrêter tous les membres sur le chemin |
| `/playzbots faction tp <faction> <x y z\|player>`| Téléportez progressivement toute la faction |

### Commandes du kit de faction

| Commande | Descriptif |
|---------|-------------|
| `/playzbots faction kit give-kit <faction> <kitname>`| Offrez un kit à tous les membres |
| `/playzbots faction kit give-kit-random <faction> <kit1> <w1>% [<kit2> <w2>% ...]`| Donnez un kit pondéré aléatoirement aux membres de la faction |

Voir [Factions](Factions) pour une utilisation détaillée.
