# 🤖 Bot PVP - Wiki

Bienvenue dans la documentation officielle du Bot PVP !

---

## 📖 À propos

PlayzBots est un mod Minecraft Fabric qui ajoute des robots de combat intelligents alimentés par le mod HeroBot. Créez des armées de robots, organisez-les en factions et regardez des batailles épiques se dérouler !

---

## 🚀 Démarrage rapide

1. Installez [Fabric Loader](https://fabricmc.net/) et [HeroBot Mod](https://modrinth.com/mod/herobot)
2. Téléchargez PlayzBots et placez-le dans votre`mods`dossier
3. Démarrez le jeu et utilisez`/playzbots spawn BotName`pour créer votre premier bot !

---

## 📚Documentation

| Pages | Descriptif |
|------|-------------|
| [🎮 Commandes](https://github.com/SatyamPlayz/PlayzBots/wiki/Commands) | Toutes les commandes disponibles |
| [⚔️ Système de combat](https://github.com/SatyamPlayz/PlayzBots/wiki/Combat) | Comment les robots se battent |
| [🚶Navigation](https://github.com/SatyamPlayz/PlayzBots/wiki/Navigation) | Orientation de base |
| [🛤️ Chemins](https://github.com/SatyamPlayz/PlayzBots/wiki/Paths) | Système de chemin et waypoints |
| [👥 Factions](https://github.com/SatyamPlayz/PlayzBots/wiki/Factions) | Système d'équipe |
| [🎒Kits](https://github.com/SatyamPlayz/PlayzBots/wiki/Kits) | Préréglages d'équipement |
| [⚙️ Paramètres](https://github.com/SatyamPlayz/PlayzBots/wiki/Settings) | Toutes les options de configuration |

---

## 💡 Exemples rapides

### Créer un bot simple
```
/playzbots spawn MyBot
```

### Faites combattre deux équipes
```
/playzbots spawn Red1
/playzbots spawn Blue1
/playzbots faction create Red
/playzbots faction create Blue
/playzbots faction add Red Red1
/playzbots faction add Blue Blue1
/playzbots faction hostile Red Blue
```

---

## 🔗 Liens

- [Dépôt GitHub](https://github.com/SatyamPlayz/PlayzBots)
- [Page Modrinth](https://modrinth.com/mod/pvp-bot)
- [Rapports de bugs](https://github.com/SatyamPlayz/PlayzBots/issues)
