package org.stepan1411.PlayzBots.client;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PlayzBotsClient implements ClientModInitializer {

    private static final Logger LOGGER = LoggerFactory.getLogger("PLAYZBOTS_CLIENT");

    @Override
    public void onInitializeClient() {
        LOGGER.info("PlayzBots client initialized");
    }
}
