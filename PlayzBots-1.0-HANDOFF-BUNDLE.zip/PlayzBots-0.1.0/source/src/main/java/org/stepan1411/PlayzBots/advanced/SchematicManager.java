package org.stepan1411.PlayzBots.advanced;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.util.Identifier;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Lightweight, server-side JSON schematic format used by PlayzBots.
 * File: config/playzbots/schematics/<name>.json
 * {"size":[x,y,z],"blocks":[{"x":0,"y":0,"z":0,"block":"minecraft:stone"}]}
 */
public final class SchematicManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Path dir;
    private static final Map<String, Schematic> cache = new HashMap<>();

    public record Block(int x, int y, int z, String block) {}
    public static final class Schematic {
        public String name;
        public int[] size = new int[]{1,1,1};
        public List<Block> blocks = new ArrayList<>();
    }

    public static void init() {
        dir = FabricLoader.getInstance().getConfigDir().resolve("playzbots").resolve("schematics");
        try { Files.createDirectories(dir); } catch (IOException ignored) {}
        cache.clear();
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir, "*.json")) {
            for (Path p : ds) load(p.getFileName().toString().replaceFirst("\\.json$", ""));
        } catch (IOException ignored) {}
    }

    public static boolean load(String name) {
        if (dir == null) init();
        Path p = dir.resolve(safe(name) + ".json");
        if (!Files.exists(p)) return false;
        try (Reader r = Files.newBufferedReader(p)) {
            Schematic s = GSON.fromJson(r, Schematic.class);
            if (s == null || s.blocks == null) return false;
            s.name = name;
            cache.put(name, s);
            return true;
        } catch (Exception e) { return false; }
    }

    public static boolean save(String name, Schematic s) {
        if (dir == null) init();
        s.name = name;
        try (Writer w = Files.newBufferedWriter(dir.resolve(safe(name) + ".json"))) {
            GSON.toJson(s, w); cache.put(name, s); return true;
        } catch (Exception e) { return false; }
    }

    public static Schematic get(String name) { return cache.get(name); }
    public static Set<String> names() { return Collections.unmodifiableSet(cache.keySet()); }
    public static Identifier blockId(Block b) { return Identifier.tryParse(b.block()); }
    private static String safe(String s) { return s.replaceAll("[^a-zA-Z0-9_.-]", "_"); }
}
