package org.stepan1411.PlayzBots;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.MinecraftServer;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.stepan1411.PlayzBots.bot.BotCombat;
import org.stepan1411.PlayzBots.bot.BotKits;
import org.stepan1411.PlayzBots.bot.BotManager;
import org.stepan1411.PlayzBots.bot.BotPath;
import org.stepan1411.PlayzBots.bot.BotSettings;
import org.stepan1411.PlayzBots.bot.BotTicker;
import org.stepan1411.PlayzBots.advanced.AdvancedCommands;
import org.stepan1411.PlayzBots.advanced.BotTaskManager;
import org.stepan1411.PlayzBots.advanced.SchematicManager;
import org.stepan1411.PlayzBots.api.PlayzBotsApiServer;
import org.stepan1411.PlayzBots.command.BotCommand;
import org.stepan1411.PlayzBots.config.WorldConfigHelper;
import org.stepan1411.PlayzBots.network.BotPayloads;
import org.stepan1411.PlayzBots.network.BotSettingsReader;
import org.stepan1411.PlayzBots.network.BotSettingsUpdater;
import org.stepan1411.PlayzBots.network.SettingsPayloads;
import org.stepan1411.PlayzBots.stats.StatsReporter;


import java.util.ArrayList;
import java.util.List;

public class PlayzBotsMod implements ModInitializer {
    public static final String MOD_ID = "PlayzBots";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Initializing PlayzBots");

        StatsReporter.init();
        registerPayloads();
        registerCommands();
        registerServerEvents();
        registerTickEvents();

        LOGGER.info("playzbots initialized");
    }

    private void registerPayloads() {
        PayloadTypeRegistry.playC2S().register(SettingsPayloads.SettingsRequestPayload.ID, SettingsPayloads.SettingsRequestPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SettingsPayloads.SettingsUpdatePayload.ID, SettingsPayloads.SettingsUpdatePayload.CODEC);
        PayloadTypeRegistry.playC2S().register(BotPayloads.BotListRequestPayload.ID, BotPayloads.BotListRequestPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(BotPayloads.BotActionPayload.ID, BotPayloads.BotActionPayload.CODEC);

        PayloadTypeRegistry.playS2C().register(SettingsPayloads.SettingsResponsePayload.ID, SettingsPayloads.SettingsResponsePayload.CODEC);
        PayloadTypeRegistry.playS2C().register(BotPayloads.BotListResponsePayload.ID, BotPayloads.BotListResponsePayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(SettingsPayloads.SettingsRequestPayload.ID, (payload, context) -> {
            var player = context.player();
            var response = new SettingsPayloads.SettingsResponsePayload(BotSettingsReader.readAll());
            ServerPlayNetworking.send(player, response);
        });

        ServerPlayNetworking.registerGlobalReceiver(SettingsPayloads.SettingsUpdatePayload.ID, (payload, context) -> {
            BotSettingsUpdater.update(payload.key(), payload.value());
        });

        ServerPlayNetworking.registerGlobalReceiver(BotPayloads.BotListRequestPayload.ID, (payload, context) -> {
            var player = context.player();
            var bots = new ArrayList<>(BotManager.getAllBots());
            var response = new BotPayloads.BotListResponsePayload(bots);
            ServerPlayNetworking.send(player, response);
        });

        ServerPlayNetworking.registerGlobalReceiver(BotPayloads.BotActionPayload.ID, (payload, context) -> {
            var server = context.server();
            var source = server.getCommandSource();
            var dispatcher = server.getCommandManager().getDispatcher();
            String botName = payload.botName();
            String action = payload.action();
            try {
                switch (action) {
                    case "remove" -> dispatcher.execute("playzbots remove " + botName, source);
                    case "attack" -> {
                        String target = payload.botName();
                        dispatcher.execute("playzbots bot-management attack " + botName + " " + target, source);
                    }
                    default -> context.player().sendMessage(Text.literal("Unknown action: " + action));
                }
            } catch (Exception e) {
                LOGGER.warn("Failed to execute bot action '{}' for '{}': {}", action, botName, e.getMessage());
            }
        });
    }

    private void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            BotCommand.register(dispatcher);
            AdvancedCommands.register(dispatcher);
        });
    }

    private void registerServerEvents() {
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            StatsReporter.onServerStarted(server);
            WorldConfigHelper.init(server);
            BotKits.init(server);
            BotPath.init();
            BotManager.init(server);
            BotTaskManager.init();
            SchematicManager.init();
            PlayzBotsApiServer.init(server);
            PlayzBotsApiServer.start();

        });

        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            BotManager.updateBotData(server);
            BotManager.saveBots();
            PlayzBotsApiServer.stop();
            BotTaskManager.stopAll();
            BotManager.reset(server);
        });
    }

    private void registerTickEvents() {
        BotTicker.register();
    }
}
