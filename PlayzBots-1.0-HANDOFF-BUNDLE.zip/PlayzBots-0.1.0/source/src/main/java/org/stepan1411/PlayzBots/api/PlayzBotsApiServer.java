package org.stepan1411.PlayzBots.api;

import com.google.gson.*;
import com.sun.net.httpserver.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.stepan1411.PlayzBots.advanced.BotTaskManager;
import org.stepan1411.PlayzBots.advanced.SchematicManager;
import org.stepan1411.PlayzBots.bot.BotManager;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.SecureRandom;
import java.util.*;
import java.util.concurrent.Executors;

/** Authenticated HTTP control API. It never evaluates Java/code or accepts filesystem paths from clients. */
public final class PlayzBotsApiServer {
    private static final Gson GSON=new GsonBuilder().create();
    private static HttpServer server; private static String token; private static int port=8765;
    private static MinecraftServer mc;
    private static Path cfg;
    public static void init(MinecraftServer s){mc=s; cfg=s.getSavePath(net.minecraft.util.WorldSavePath.ROOT).resolve("playzbots-api.json"); load();}
    public static synchronized void start(){ if(server!=null)return; try{
        if(token==null||token.length()<32){token=newToken();save();}
        server=HttpServer.create(new InetSocketAddress("0.0.0.0",port),0); server.setExecutor(Executors.newFixedThreadPool(4));
        server.createContext("/api/status", PlayzBotsApiServer::status); server.createContext("/api/bots",PlayzBotsApiServer::bots); server.createContext("/api/action",PlayzBotsApiServer::action); server.createContext("/api/schematic",PlayzBotsApiServer::schematic);
        server.start(); System.out.println("[PlayzBots] API listening on port "+port);
    }catch(Exception e){System.out.println("[PlayzBots] API start failed: "+e.getMessage());}}
    public static synchronized void stop(){if(server!=null){server.stop(0);server=null;}}
    public static String token(){return token;}
    private static boolean auth(HttpExchange x){String a=x.getRequestHeaders().getFirst("Authorization");return a!=null&&a.equals("Bearer "+token);}
    private static void status(HttpExchange x)throws IOException{if(!guard(x))return; Map<String,Object> o=new LinkedHashMap<>();o.put("online",true);o.put("bots",BotManager.getBotCount());o.put("players",mc.getCurrentPlayerCount());o.put("maxPlayers",mc.getMaxPlayerCount());o.put("tps",20.0);send(x,200,o);}
    private static void bots(HttpExchange x)throws IOException{if(!guard(x))return;List<Map<String,Object>> a=new ArrayList<>();for(String n:BotManager.getAllBots()){ServerPlayerEntity b=BotManager.getBot(mc,n);if(b==null)continue;Map<String,Object> o=new LinkedHashMap<>();o.put("name",n);o.put("health",b.getHealth());o.put("maxHealth",b.getMaxHealth());o.put("x",b.getX());o.put("y",b.getY());o.put("z",b.getZ());o.put("task",Optional.ofNullable(BotTaskManager.get(n)).map(t->t.type.name()).orElse("IDLE"));a.add(o);}send(x,200,a);}
    private static void action(HttpExchange x)throws IOException{if(!guard(x))return;if(!x.getRequestMethod().equalsIgnoreCase("POST")){sendText(x,405,"POST required");return;}JsonObject j=JsonParser.parseString(read(x)).getAsJsonObject();String bot=j.get("bot").getAsString();String a=j.get("action").getAsString();mc.execute(()->{ServerPlayerEntity b=BotManager.getBot(mc,bot);if(b==null)return;switch(a){case"stop"->BotTaskManager.stop(bot);case"follow"->BotTaskManager.follow(bot,j.get("target").getAsString());case"guard"->BotTaskManager.guard(bot,b.getPos(),j.has("radius")?j.get("radius").getAsInt():10);case"mine"->BotTaskManager.mine(bot,j.get("block").getAsString(),j.has("radius")?j.get("radius").getAsInt():16);case"farm"->BotTaskManager.farm(bot,j.has("radius")?j.get("radius").getAsInt():16);}});sendText(x,202,"accepted");}
    private static void schematic(HttpExchange x)throws IOException{if(!guard(x))return;if(!x.getRequestMethod().equalsIgnoreCase("POST")){sendText(x,405,"POST required");return;}JsonObject j=JsonParser.parseString(read(x)).getAsJsonObject();String name=j.get("name").getAsString();SchematicManager.Schematic s=GSON.fromJson(j.get("schematic"),SchematicManager.Schematic.class);boolean ok=SchematicManager.save(name,s);sendText(x,ok?200:400,ok?"saved":"save failed");}
    private static boolean guard(HttpExchange x)throws IOException{if(auth(x))return true;sendText(x,401,"unauthorized");return false;}
    private static String read(HttpExchange x)throws IOException{return new String(x.getRequestBody().readAllBytes(),StandardCharsets.UTF_8);}
    private static void send(HttpExchange x,int c,Object o)throws IOException{sendText(x,c,GSON.toJson(o));}
    private static void sendText(HttpExchange x,int c,String s)throws IOException{byte[]b=s.getBytes(StandardCharsets.UTF_8);x.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");x.sendResponseHeaders(c,b.length);try(OutputStream os=x.getResponseBody()){os.write(b);}}
    private static String newToken(){byte[]b=new byte[32];new SecureRandom().nextBytes(b);return Base64.getUrlEncoder().withoutPadding().encodeToString(b);}
    private static void load(){try{if(Files.exists(cfg)){JsonObject j=JsonParser.parseString(Files.readString(cfg)).getAsJsonObject();port=j.has("port")?j.get("port").getAsInt():8765;token=j.has("token")?j.get("token").getAsString():null;}}catch(Exception ignored){}}
    private static void save(){try{JsonObject j=new JsonObject();j.addProperty("port",port);j.addProperty("token",token);Files.writeString(cfg,GSON.toJson(j));}catch(Exception ignored){}}
}
