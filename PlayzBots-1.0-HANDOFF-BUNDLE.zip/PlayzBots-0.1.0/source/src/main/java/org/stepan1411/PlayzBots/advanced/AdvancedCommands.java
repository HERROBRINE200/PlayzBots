package org.stepan1411.PlayzBots.advanced;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import org.stepan1411.PlayzBots.api.PlayzBotsApiServer;
import org.stepan1411.PlayzBots.bot.BotManager;

/** Adds the non-PvP survival automation surface to the existing /playzbots tree. */
public final class AdvancedCommands {
    public static void register(com.mojang.brigadier.CommandDispatcher<ServerCommandSource> d) {
        var root = CommandManager.literal("playzbots").requires(x -> x.hasPermissionLevel(2));
        var task=CommandManager.literal("task");
        task.then(CommandManager.literal("stop").then(CommandManager.argument("bot",StringArgumentType.word()).executes(c->{BotTaskManager.stop(c.getArgument("bot",String.class));msg(c,"Task stopped");return 1;})));
        var follow=CommandManager.literal("follow").then(CommandManager.argument("bot",StringArgumentType.word()).then(CommandManager.argument("player",StringArgumentType.word()).executes(c->{String n=c.getArgument("bot",String.class);BotTaskManager.follow(n,c.getArgument("player",String.class));msg(c,"Follow task assigned");return 1;})));
        task.then(follow);
        var guard=CommandManager.literal("guard").then(CommandManager.argument("bot",StringArgumentType.word()).then(CommandManager.argument("radius",IntegerArgumentType.integer(1,128)).executes(c->{String n=c.getArgument("bot",String.class);var b=BotManager.getBot(c.getSource().getServer(),n);if(b==null)return err(c,"Bot not found");BotTaskManager.guard(n,b.getPos(),c.getArgument("radius",Integer.class));msg(c,"Guard task assigned");return 1;})));
        task.then(guard);
        var mine=CommandManager.literal("mine").then(CommandManager.argument("bot",StringArgumentType.word()).then(CommandManager.argument("block",StringArgumentType.word()).then(CommandManager.argument("radius",IntegerArgumentType.integer(2,32)).executes(c->{BotTaskManager.mine(c.getArgument("bot",String.class),c.getArgument("block",String.class),c.getArgument("radius",Integer.class));msg(c,"Mining task assigned");return 1;}))));
        task.then(mine);
        var farm=CommandManager.literal("farm").then(CommandManager.argument("bot",StringArgumentType.word()).then(CommandManager.argument("radius",IntegerArgumentType.integer(2,64)).executes(c->{BotTaskManager.farm(c.getArgument("bot",String.class),c.getArgument("radius",Integer.class));msg(c,"Farming task assigned");return 1;})));
        task.then(farm);
        root.then(task);

        var schem=CommandManager.literal("schematic");
        schem.then(CommandManager.literal("list").executes(c->{msg(c,String.join(", ",SchematicManager.names()));return 1;}));
        schem.then(CommandManager.literal("load").then(CommandManager.argument("name",StringArgumentType.word()).executes(c->{boolean ok=SchematicManager.load(c.getArgument("name",String.class));msg(c,ok?"Loaded schematic":"Schematic not found");return ok?1:0;})));
        root.then(schem);

        var build=CommandManager.literal("build");
        build.then(CommandManager.literal("assign")
            .then(CommandManager.argument("bot",StringArgumentType.word())
            .then(CommandManager.argument("schematic",StringArgumentType.word())
            .then(CommandManager.argument("x",DoubleArgumentType.doubleArg())
            .then(CommandManager.argument("y",DoubleArgumentType.doubleArg())
            .then(CommandManager.argument("z",DoubleArgumentType.doubleArg()).executes(c->{
                String b=c.getArgument("bot",String.class), s=c.getArgument("schematic",String.class);
                if(SchematicManager.get(s)==null&&!SchematicManager.load(s))return err(c,"Schematic not found");
                BotTaskManager.build(b,s,new Vec3d(c.getArgument("x",Double.class),c.getArgument("y",Double.class),c.getArgument("z",Double.class))); msg(c,"Build task assigned"); return 1;
            })))))));
        build.then(CommandManager.literal("assign-all")
            .then(CommandManager.argument("schematic",StringArgumentType.word())
            .then(CommandManager.argument("x",DoubleArgumentType.doubleArg())
            .then(CommandManager.argument("y",DoubleArgumentType.doubleArg())
            .then(CommandManager.argument("z",DoubleArgumentType.doubleArg()).executes(c->{
                String s=c.getArgument("schematic",String.class); if(SchematicManager.get(s)==null&&!SchematicManager.load(s))return err(c,"Schematic not found");
                Vec3d p=new Vec3d(c.getArgument("x",Double.class),c.getArgument("y",Double.class),c.getArgument("z",Double.class));
                for(String b:BotManager.getAllBots())BotTaskManager.build(b,s,p); msg(c,"Build distributed to "+BotManager.getBotCount()+" bots"); return 1;
            }))))));
        root.then(build);

        var api=CommandManager.literal("api");
        api.then(CommandManager.literal("start").executes(c->{PlayzBotsApiServer.start();msg(c,"Remote API started");return 1;}));
        api.then(CommandManager.literal("stop").executes(c->{PlayzBotsApiServer.stop();msg(c,"Remote API stopped");return 1;}));
        api.then(CommandManager.literal("token").executes(c->{msg(c,"API token: "+PlayzBotsApiServer.token());return 1;}));
        root.then(api);
        d.register(root);
    }
    private static void msg(com.mojang.brigadier.context.CommandContext<ServerCommandSource> c,String s){c.getSource().sendFeedback(()->Text.literal("[PlayzBots] "+s),false);}
    private static int err(com.mojang.brigadier.context.CommandContext<ServerCommandSource> c,String s){c.getSource().sendError(Text.literal("[PlayzBots] "+s));return 0;}
}
