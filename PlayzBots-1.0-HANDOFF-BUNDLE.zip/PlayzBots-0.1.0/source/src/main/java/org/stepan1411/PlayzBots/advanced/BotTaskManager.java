package org.stepan1411.PlayzBots.advanced;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.CropBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.registry.Registries;
import org.stepan1411.PlayzBots.bot.BotManager;
import org.stepan1411.PlayzBots.bot.BotNavigation;

import java.util.*;

/** Deterministic task scheduler. Tasks are deliberately tick-safe and never execute arbitrary code. */
public final class BotTaskManager {
    public enum Type { IDLE, FOLLOW, GUARD, MINE, FARM, BUILD }
    public static final class Task {
        public Type type = Type.IDLE;
        public String target;
        public String block;
        public String schematic;
        public Vec3d point;
        public int radius = 16;
        public int cursor;
    }
    private static final Map<String, Task> tasks = new HashMap<>();

    public static void init() { tasks.clear(); }
    public static Task get(String bot) { return tasks.get(bot); }
    public static void stop(String bot) { tasks.remove(bot); }
    public static void stopAll() { tasks.clear(); }
    public static void follow(String bot, String player) { Task t = base(Type.FOLLOW); t.target=player; tasks.put(bot,t); }
    public static void guard(String bot, Vec3d p, int radius) { Task t=base(Type.GUARD); t.point=p; t.radius=Math.max(1,radius); tasks.put(bot,t); }
    public static void mine(String bot, String block, int radius) { Task t=base(Type.MINE); t.block=block; t.radius=Math.max(2,radius); tasks.put(bot,t); }
    public static void farm(String bot, int radius) { Task t=base(Type.FARM); t.radius=Math.max(2,radius); tasks.put(bot,t); }
    public static void build(String bot, String schematic, Vec3d origin) { Task t=base(Type.BUILD); t.schematic=schematic; t.point=origin; tasks.put(bot,t); }
    private static Task base(Type type){ Task t=new Task(); t.type=type; return t; }

    public static void tick(MinecraftServer server) {
        for (String name : new ArrayList<>(BotManager.getAllBots())) {
            ServerPlayerEntity bot = BotManager.getBot(server, name); if (bot==null || !bot.isAlive()) continue;
            Task t=tasks.get(name); if(t==null) continue;
            try { switch(t.type) {
                case FOLLOW -> doFollow(server,bot,t);
                case GUARD -> doGuard(bot,t);
                case MINE -> doMine(bot,t);
                case FARM -> doFarm(bot,t);
                case BUILD -> doBuild(bot,t);
                default -> {}
            }} catch(Exception ignored) {}
        }
    }
    private static void doFollow(MinecraftServer s, ServerPlayerEntity b, Task t){
        ServerPlayerEntity p=s.getPlayerManager().getPlayer(t.target); if(p==null) return;
        double d=b.distanceTo(p); if(d>3) BotNavigation.moveToward(b,p,1.0); else if(d<1.5) BotNavigation.moveAway(b,p,0.35);
    }
    private static void doGuard(ServerPlayerEntity b, Task t){
        if(t.point==null)return; double d=b.getPos().distanceTo(t.point); if(d>t.radius) BotNavigation.moveTowardPosition(b,t.point,1.0);
    }
    private static void doMine(ServerPlayerEntity b, Task t){
        BlockPos pos=findBlock(b,t.block,t.radius); if(pos==null)return;
        double d=b.getPos().distanceTo(Vec3d.ofCenter(pos)); if(d>4){BotNavigation.moveTowardPosition(b,Vec3d.ofCenter(pos),1.0);return;}
        b.getEntityWorld().breakBlock(pos,true,b);
    }
    private static BlockPos findBlock(ServerPlayerEntity b,String id,int radius){
        Identifier ident=Identifier.tryParse(id); if(ident==null)return null; Block wanted=Registries.BLOCK.get(ident);
        BlockPos base=b.getBlockPos(); BlockPos best=null; double bd=Double.MAX_VALUE;
        for(int x=-radius;x<=radius;x++)for(int y=-radius;y<=radius;y++)for(int z=-radius;z<=radius;z++){
            BlockPos p=base.add(x,y,z); if(b.getEntityWorld().getBlockState(p).isOf(wanted)) {double d=b.squaredDistanceTo(Vec3d.ofCenter(p)); if(d<bd){bd=d;best=p;}}
        } return best;
    }
    private static void doFarm(ServerPlayerEntity b,Task t){
        BlockPos base=b.getBlockPos(); BlockPos best=null; double bd=Double.MAX_VALUE;
        for(int x=-t.radius;x<=t.radius;x++)for(int z=-t.radius;z<=t.radius;z++)for(int y=-2;y<=3;y++){
            BlockPos p=base.add(x,y,z); var st=b.getEntityWorld().getBlockState(p); if(st.getBlock() instanceof CropBlock crop && crop.isMature(st)) {double d=b.squaredDistanceTo(Vec3d.ofCenter(p));if(d<bd){bd=d;best=p;}}
        }
        if(best!=null){if(b.getPos().distanceTo(Vec3d.ofCenter(best))>4)BotNavigation.moveTowardPosition(b,Vec3d.ofCenter(best),1);else b.getEntityWorld().breakBlock(best,true,b);}
    }
    private static void doBuild(ServerPlayerEntity b,Task t){
        SchematicManager.Schematic s=SchematicManager.get(t.schematic); if(s==null)return;
        if(t.cursor>=s.blocks.size()){stop(b.getName().getString());return;}
        // Work is partitioned by stable bot-name hash so multiple bots can build simultaneously.
        int n=Math.max(1,BotManager.getAllBots().size()); int slot=Math.floorMod(b.getName().getString().hashCode(),n);
        for(int i=t.cursor;i<s.blocks.size();i++){
            if(i % n != slot) continue; t.cursor=i+1; var sb=s.blocks.get(i); BlockPos p=new BlockPos((int)t.point.x+sb.x,(int)t.point.y+sb.y,(int)t.point.z+sb.z);
            if(!b.getEntityWorld().getBlockState(p).isAir()) continue; Identifier id=Identifier.tryParse(sb.block); if(id==null)continue; Block block=Registries.BLOCK.get(id);
            if(b.getPos().distanceTo(Vec3d.ofCenter(p))>5){BotNavigation.moveTowardPosition(b,Vec3d.ofCenter(p),1);return;}
            b.getEntityWorld().setBlockState(p,block.getDefaultState()); return;
        }
        stop(b.getName().getString());
    }
}
