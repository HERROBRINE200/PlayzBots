# PlayzBots

Minecraft Fabric 1.21.11 advanced bot-control mod for PlayzBots.

## Command

The public command is now:

`/playzbots`

All PlayzBots controls require operator permission (level 2).

Existing combat, settings, faction, kit and path systems are retained and their command references use `/playzbots`.

## Dependencies

- Minecraft 1.21.11
- Fabric API 0.141.x for 1.21.11
- HeroBot 1.21.11

## Branding

Creator: SatyamPlayz

The old PlayzBots branding and public `/playzbots` command are removed from the PlayzBots source configuration and user-facing text.

## Build

Use the included Gradle wrapper. The build requires access to the configured Gradle/Fabric repositories.
