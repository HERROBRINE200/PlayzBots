# PlayzBots build status

## Included in this source release
- Existing PvP/combat, navigation, factions, kits and paths from the supplied bot project.
- `/playzbots` branding and OP-only command tree.
- Survival task engine: follow, guard, mine, farm and schematic build.
- Multi-bot schematic work partitioning.
- Server-side JSON schematic library under `config/playzbots/schematics/`.
- Authenticated HTTP remote API on port 8765 with generated bearer token.
- Mobile/PWA control panel in `mobile/`.
- Persistent API token/config and server-side validation.

## Schematic JSON format
```json
{
  "size": [3,3,3],
  "blocks": [
    {"x":0,"y":0,"z":0,"block":"minecraft:stone"}
  ]
}
```

## Commands
- `/playzbots task follow <bot> <player>`
- `/playzbots task guard <bot> <radius>`
- `/playzbots task mine <bot> <block> <radius>`
- `/playzbots task farm <bot> <radius>`
- `/playzbots task stop <bot>`
- `/playzbots schematic list`
- `/playzbots schematic load <name>`
- `/playzbots build assign <bot> <schematic> <x> <y> <z>`
- `/playzbots build assign-all <schematic> <x> <y> <z>`
- `/playzbots api start|stop|token`

The supplied environment could not perform a fresh Gradle dependency download, so this source release is not falsely marked as compiled/tested here. The existing core JAR remains included separately.
