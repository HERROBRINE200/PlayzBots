# PlayzBots Mobile

This is an installable mobile web app/PWA for the PlayzBots HTTP API. Put the folder on any static web host or serve it from your preferred local web server, then open it on Android and use **Add to Home screen**.

The mod API uses `Authorization: Bearer <token>` and never executes Java, shell commands, or arbitrary file paths from the phone.
