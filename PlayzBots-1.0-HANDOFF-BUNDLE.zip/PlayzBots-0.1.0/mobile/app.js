let base='',token='';
function connect(){base=document.getElementById('url').value.replace(/\/$/,'');token=document.getElementById('token').value;localStorage.pb=JSON.stringify({base,token});poll()}
async function api(path,opt={}){opt.headers=Object.assign({'Authorization':'Bearer '+token,'Content-Type':'application/json'},opt.headers||{});let r=await fetch(base+path,opt);if(!r.ok)throw Error(await r.text());return r.json().catch(()=>({}))}
async function poll(){try{let s=await api('/api/status');document.getElementById('state').textContent='Online';players.textContent=s.players;bots.textContent=s.bots;tps.textContent=s.tps;let a=await api('/api/bots');list.innerHTML=a.map(b=>`<div class="bot"><b>${esc(b.name)}</b><div class="muted">HP ${b.health}/${b.maxHealth} · ${b.task}<br>${b.x.toFixed(1)}, ${b.y.toFixed(1)}, ${b.z.toFixed(1)}</div><button onclick="act('${esc(b.name)}','stop')">Stop</button><button onclick="act('${esc(b.name)}','farm')">Farm</button><button onclick="mine('${esc(b.name)}')">Mine</button></div>`).join('')}catch(e){document.getElementById('state').textContent='Offline'}setTimeout(poll,1500)}
async function act(bot,action,extra={}){await api('/api/action',{method:'POST',body:JSON.stringify({bot,action,...extra})})}
async function mine(bot){let block=prompt('Block ID','minecraft:iron_ore');if(block)await act(bot,'mine',{block,radius:16})}
function esc(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
try{let x=JSON.parse(localStorage.pb||'null');if(x){url.value=x.base;token.value=x.token}}catch{}
